# Kansas City

Emergency restoration blueprint under development.
