# El Paso

Emergency restoration blueprint under development.
