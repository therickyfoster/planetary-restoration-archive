# Honor Metrics
Tracking reputation and healing impact per region.