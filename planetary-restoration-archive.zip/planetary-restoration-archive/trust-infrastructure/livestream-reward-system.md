# Livestream Reward System
Details on real-time funding of first responders via blockchain.