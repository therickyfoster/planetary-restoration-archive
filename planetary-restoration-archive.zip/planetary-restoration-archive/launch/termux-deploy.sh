#!/bin/bash
echo 'Deploying from Termux...'
git add .
git commit -m "Deploy from Termux"
git push origin main