# California Deployment Plan
Fire defense and drought mitigation.