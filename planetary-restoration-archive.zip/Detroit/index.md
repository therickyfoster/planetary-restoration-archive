# Detroit

Emergency restoration blueprint under development.
